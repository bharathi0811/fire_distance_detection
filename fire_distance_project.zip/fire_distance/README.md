# distance-measure

https://buffml.com/distance-measure-in-python/


https://youtu.be/Jy9R_7eNNhI
